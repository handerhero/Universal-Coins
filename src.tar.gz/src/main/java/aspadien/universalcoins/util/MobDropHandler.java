package aspadien.universalcoins.util;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.attributes.Attributes;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.monster.IMob;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import static aspadien.universalcoins.UniversalCoins.MOD_ID;

@Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class MobDropHandler {

    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        LivingEntity entity = (LivingEntity) event.getEntity();

        // В 1.16.5 класс называется World, даже если само поле называется level
        World level = entity.level;

        // 1. Прерываем выполнение, если это клиент (оставляем только сервер)
        if (level.isClientSide) return;

        // 2. Проверяем, что моб враждебный
        if (entity instanceof IMob) {

            float maxHealth = entity.getMaxHealth();

            double attackDamage = 0;
            if (entity.getAttribute(Attributes.ATTACK_DAMAGE) != null) {
                attackDamage = entity.getAttributeValue(Attributes.ATTACK_DAMAGE);
            }

            int dropAmount = (int) (maxHealth / 20.0f) + (int) (attackDamage / 5.0);

            if (dropAmount > 0) {
                ItemStack customDrop = new ItemStack(Items.DIAMOND, dropAmount);

                ItemEntity itemEntity = new ItemEntity(
                        level,
                        entity.getX(),
                        entity.getY(),
                        entity.getZ(),
                        customDrop
                );

                itemEntity.setDefaultPickUpDelay();

                event.getDrops().add(itemEntity);
            }
        }
    }
}