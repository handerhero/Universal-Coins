/*     */ package aspadien.universalcoins.util;
/*     */ 
/*     */ import net.minecraft.nbt.CompoundNBT;
/*     */ 
/*     */ public class UniversalAccounts
/*     */ {
/*   7 */   private static final UniversalAccounts instance = new UniversalAccounts();
/*     */   
/*     */   public static UniversalAccounts getInstance() {
/*  10 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getAccountBalance(String accountNumber) {
/*  18 */     if (hasKey(accountNumber)) {
/*  19 */       return getWorldLong(accountNumber);
/*     */     }
/*  21 */     return -1L;
/*     */   }
/*     */   
/*     */   public boolean debitAccount(String accountNumber, long amount, boolean simulate) {
/*  25 */     if (hasKey(accountNumber)) {
/*  26 */       long balance = getWorldLong(accountNumber);
/*  27 */       if (amount <= balance) {
/*  28 */         if (!simulate) {
/*  29 */           balance -= amount;
/*  30 */           setWorldData(accountNumber, balance);
/*     */         } 
/*  32 */         return true;
/*     */       } 
/*     */     } 
/*  35 */     return false;
/*     */   }
/*     */   
/*     */   public boolean creditAccount(String accountNumber, long amount, boolean simulate) {
/*  39 */     if (hasKey(accountNumber)) {
/*  40 */       long balance = getWorldLong(accountNumber);
/*  41 */       if (Long.MAX_VALUE - balance >= amount) {
/*  42 */         if (!simulate) {
/*  43 */           balance += amount;
/*  44 */           setWorldData(accountNumber, balance);
/*     */         } 
/*  46 */         return true;
/*     */       } 
/*     */     } 
/*  49 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPlayerAccount(String playerUID) {
/*  54 */     return getWorldString(playerUID);
/*     */   }
/*     */   
/*     */   public String getOrCreatePlayerAccount(String playerUID) {
/*  58 */     String accountNumber = getWorldString(playerUID);
/*  59 */     if (accountNumber.isEmpty()) {
/*  60 */       while (!hasKey(playerUID)) {
/*  61 */         accountNumber = String.valueOf(generateAccountNumber());
/*  62 */         if (getWorldString(accountNumber).isEmpty()) {
/*  63 */           setWorldData(playerUID, accountNumber);
/*  64 */           setWorldData(accountNumber, 0L);
/*     */         } 
/*     */       } 
/*     */     }
/*  68 */     return accountNumber;
/*     */   }
/*     */   
/*     */   public boolean addPlayerAccount(String playerUID) {
/*  72 */     if (getWorldString(playerUID).isEmpty())
/*     */       while (true) {
/*     */         
/*  75 */         String accountNumber = String.valueOf(generateAccountNumber());
/*  76 */         if (!hasKey(accountNumber)) {
/*  77 */           setWorldData(playerUID, accountNumber);
/*  78 */           setWorldData(accountNumber, 0L);
/*  79 */           return true;
/*     */         } 
/*  81 */       }   return false;
/*     */   }
/*     */   
/*     */   public void transferPlayerAccount(String playerUID) {
/*  85 */     String oldAccount = getWorldString(playerUID);
/*  86 */     long oldBalance = getAccountBalance(oldAccount);
/*  87 */     delWorldData(playerUID);
/*  88 */     delWorldData(oldAccount);
/*  89 */     String accountNumber = oldAccount;
/*     */     while (true) {
/*  91 */       accountNumber = String.valueOf(generateAccountNumber());
/*  92 */       if (!hasKey(accountNumber)) {
/*  93 */         setWorldData(playerUID, accountNumber);
/*  94 */         setWorldData(accountNumber, oldBalance);
/*     */         return;
/*     */       } 
/*     */     }  } private int generateAccountNumber() {
/*  98 */     return (int)(Math.floor(Math.random() * 9.9999999E7D) + 1.1111111E7D);
/*     */   }
/*     */   
/*     */   private boolean hasKey(String tag) {
/* 102 */     UCWorldData wData = UCWorldData.getInstance();
/* 103 */     CompoundNBT wdTag = wData.getData();
/* 104 */     return wdTag.contains(tag);
/*     */   }
/*     */   
/*     */   private void setWorldData(String tag, String data) {
/* 108 */     UCWorldData wData = UCWorldData.getInstance();
/* 109 */     CompoundNBT wdTag = wData.getData();
/* 110 */     wdTag.putString(tag, data);
/* 111 */     wData.markDirty();
/*     */   }
/*     */   
/*     */   private void setWorldData(String tag, long data) {
/* 115 */     UCWorldData wData = UCWorldData.getInstance();
/* 116 */     CompoundNBT wdTag = wData.getData();
/* 117 */     wdTag.putLong(tag, data);
/* 118 */     wData.markDirty();
/*     */   }
/*     */   
/*     */   private long getWorldLong(String tag) {
/* 122 */     UCWorldData wData = UCWorldData.getInstance();
/* 123 */     CompoundNBT wdTag = wData.getData();
/* 124 */     return wdTag.getLong(tag);
/*     */   }
/*     */   
/*     */   private String getWorldString(String tag) {
/* 128 */     UCWorldData wData = UCWorldData.getInstance();
/* 129 */     CompoundNBT wdTag = wData.getData();
/* 130 */     return wdTag.getString(tag);
/*     */   }
/*     */   
/*     */   private void delWorldData(String tag) {
/* 134 */     UCWorldData wData = UCWorldData.getInstance();
/* 135 */     CompoundNBT wdTag = wData.getData();
/* 136 */     wdTag.remove(tag);
/* 137 */     wData.markDirty();
/*     */   }
/*     */ }


/* Location:              /home/aspadien/.gradle/caches/forge_gradle/deobf_dependencies/blank/examplemod/1.0.0_mapped_official_1.16.5/examplemod-1.0.0_mapped_official_1.16.5.jar!/aspadien.universalcoins/util/UniversalAccounts.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */