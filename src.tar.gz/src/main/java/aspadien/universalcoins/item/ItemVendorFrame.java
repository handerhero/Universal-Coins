/*   */ package aspadien.universalcoins.item;
/*   */ 
/*   */ import net.minecraft.item.Item;
/*   */ import net.minecraft.item.ItemFrameItem;
/*   */ 
/*   */ public class ItemVendorFrame extends ItemFrameItem {
/*   */   public ItemVendorFrame(Item.Properties p_i48486_1_) {
/* 8 */     super(p_i48486_1_);
/*   */   }
/*   */ }


/* Location:              /home/aspadien/.gradle/caches/forge_gradle/deobf_dependencies/blank/examplemod/1.0.0_mapped_official_1.16.5/examplemod-1.0.0_mapped_official_1.16.5.jar!/aspadien.universalcoins/item/ItemVendorFrame.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */