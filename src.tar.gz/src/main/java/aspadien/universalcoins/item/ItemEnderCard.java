/*     */ package aspadien.universalcoins.item;
/*     */ import java.text.DecimalFormat;
/*     */ import net.minecraft.entity.player.PlayerEntity;
/*     */ import net.minecraft.item.Item;
/*     */ import net.minecraft.item.ItemStack;
/*     */ import net.minecraft.item.ItemUseContext;
/*     */ import net.minecraft.util.ActionResultType;
/*     */ import net.minecraft.util.NonNullList;
/*     */ import net.minecraft.util.Util;
/*     */ import net.minecraft.util.text.*;
/*     */
/*     */
/*     */
/*     */ import net.minecraft.world.World;
/*     */ import aspadien.universalcoins.util.UniversalAccounts;
/*     */ 
/*     */ public class ItemEnderCard extends aspadien.universalcoins.item.ItemUCCard {
/*     */   public ItemEnderCard(Item.Properties properties) {
/*  19 */     super(properties);
/*     */   }
/*     */ 
/*     */   
/*     */   public ActionResultType useOn(ItemUseContext context) {
/*  24 */     World world = context.getLevel();
/*  25 */     PlayerEntity player = context.getPlayer();
/*  26 */     ItemStack heldItem = context.getItemInHand();
/*     */ 
/*     */     
/*  29 */     if (world.isClientSide || player == null) {
/*  30 */       return ActionResultType.SUCCESS;
/*     */     }
/*     */ 
/*     */     
/*  34 */     if (!heldItem.hasTag()) {
/*  35 */       createNBT(heldItem, world, player);
/*     */     }
/*     */     
/*  38 */     DecimalFormat formatter = new DecimalFormat("#,###,###,###");
/*  39 */     NonNullList<ItemStack> inventory = player.inventory.items;
/*  40 */     String accountNumber = heldItem.getTag().getString("Account");
/*     */ 
/*     */     
/*  43 */     long accountBalance = UniversalAccounts.getInstance().getAccountBalance(accountNumber);
/*     */ 
/*     */     
/*  46 */     if (accountBalance == -1L) {
/*  47 */       return ActionResultType.SUCCESS;
/*     */     }
/*     */     
/*  50 */     long coinsDeposited = 0L;
/*     */ 
/*     */     
/*  53 */     for (int i = 0; i < inventory.size(); i++) {
/*  54 */       ItemStack instack = (ItemStack)inventory.get(i);
/*     */ 
/*     */       
/*  57 */       int coinValue = aspadien.universalcoins.util.CoinUtils.getCoinValue(instack);
/*     */       
/*  59 */       if (coinValue > 0 && !instack.isEmpty()) {
/*     */ 
/*     */ 
/*     */         
/*  63 */         int depositAmount = 0;
/*  64 */         long currentBalance = UniversalAccounts.getInstance().getAccountBalance(accountNumber);
/*  65 */         long spaceOnAccount = Long.MAX_VALUE - currentBalance;
/*     */ 
/*     */         
/*  68 */         if (spaceOnAccount > coinValue * instack.getCount()) {
/*  69 */           depositAmount = instack.getCount();
/*     */         } else {
/*  71 */           depositAmount = (int)(spaceOnAccount / coinValue);
/*     */         } 
/*     */         
/*  74 */         if (depositAmount > 0) {
/*     */           
/*  76 */           UniversalAccounts.getInstance().creditAccount(accountNumber, coinValue * depositAmount, false);
/*  77 */           coinsDeposited += coinValue * depositAmount;
/*     */ 
/*     */           
/*  80 */           instack.shrink(depositAmount);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  85 */     if (coinsDeposited > 0L) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  90 */       IFormattableTextComponent iFormattableTextComponent1 = (new TranslationTextComponent("item.card.deposit")).append((ITextComponent)new StringTextComponent(" " + formatter.format(coinsDeposited) + " ")).append((ITextComponent)new TranslationTextComponent((coinsDeposited > 1L) ? "general.currency.multiple" : "general.currency.single")).withStyle(TextFormatting.GREEN);
/*     */       
/*  92 */       player.sendMessage((ITextComponent)iFormattableTextComponent1, Util.NIL_UUID);
/*     */     } 
/*     */ 
/*     */     
/*  96 */     long finalBalance = UniversalAccounts.getInstance().getAccountBalance(accountNumber);
/*     */ 
/*     */     
/*  99 */     IFormattableTextComponent iFormattableTextComponent = (new TranslationTextComponent("item.card.balance")).append((ITextComponent)new StringTextComponent(" " + formatter.format(finalBalance))).withStyle(TextFormatting.GOLD);
/*     */     
/* 101 */     player.sendMessage((ITextComponent)iFormattableTextComponent, Util.NIL_UUID);
/*     */     
/* 103 */     return ActionResultType.SUCCESS;
/*     */   }
/*     */ }


/* Location:              /home/aspadien/.gradle/caches/forge_gradle/deobf_dependencies/blank/examplemod/1.0.0_mapped_official_1.16.5/examplemod-1.0.0_mapped_official_1.16.5.jar!/aspadien.universalcoins/item/ItemEnderCard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */