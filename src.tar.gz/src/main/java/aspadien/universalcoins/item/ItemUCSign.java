/*    */ package aspadien.universalcoins.item;
/*    */ import net.minecraft.block.Block;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.ItemUseContext;
/*    */ import net.minecraft.state.Property;
/*    */ import net.minecraft.state.properties.BlockStateProperties;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.ActionResultType;
/*    */ import net.minecraft.util.Direction;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.util.math.MathHelper;
/*    */ import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
/*    */ import aspadien.universalcoins.init.ModBlocks;
/*    */ import aspadien.universalcoins.tileentity.TileUCSign;
/*    */ 
/*    */ public class ItemUCSign extends Item {
/*    */   public ItemUCSign(Item.Properties properties) {
/* 21 */     super(properties.stacksTo(16));
/*    */   }
/*    */ 
/*    */   
/*    */   public ActionResultType useOn(ItemUseContext context) {
/* 26 */     World world = context.getLevel();
/* 27 */     BlockPos pos = context.getClickedPos();
/* 28 */     Direction facing = context.getClickedFace();
/* 29 */     PlayerEntity player = context.getPlayer();
/* 30 */     ItemStack stack = context.getItemInHand();
/*    */     
/* 32 */     if (player == null || facing == Direction.DOWN) {
/* 33 */       return ActionResultType.FAIL;
/*    */     }
/*    */ 
/*    */     
/* 37 */     BlockState clickedState = world.getBlockState(pos);
/* 38 */     BlockPos placePos = clickedState.getMaterial().isReplaceable() ? pos : pos.relative(facing);
/*    */ 
/*    */     
/* 41 */     if (!world.getBlockState(placePos).getMaterial().isReplaceable()) {
/* 42 */       return ActionResultType.FAIL;
/*    */     }
/*    */     
/* 45 */     if (!world.isClientSide) {
/*    */       BlockState stateToPlace;
/*    */ 
/*    */       
/* 49 */       if (facing == Direction.UP) {
/*    */ 
/*    */         
/* 52 */         int rotation = MathHelper.floor(((player.yRot + 180.0F) * 16.0F / 360.0F) + 0.5D) & 0xF;
/*    */         
/* 54 */         stateToPlace = (BlockState)((Block)ModBlocks.STANDING_UC_SIGN.get()).defaultBlockState().setValue((Property)BlockStateProperties.ROTATION_16, Integer.valueOf(rotation));
/*    */       
/*    */       }
/*    */       else {
/*    */         
/* 59 */         stateToPlace = (BlockState)((Block)ModBlocks.WALL_UC_SIGN.get()).defaultBlockState().setValue((Property)BlockStateProperties.HORIZONTAL_FACING, (Comparable)facing);
/*    */       } 
/*    */ 
/*    */       
/* 63 */       if (stateToPlace.canSurvive((IWorldReader)world, placePos)) {
/* 64 */         world.setBlock(placePos, stateToPlace, 3);
/*    */ 
/*    */         
/* 67 */         if (!player.isCreative()) {
/* 68 */           stack.shrink(1);
/*    */         }
/*    */ 
/*    */         
/* 72 */         TileEntity te = world.getBlockEntity(placePos);
/* 73 */         if (te instanceof TileUCSign) {
/* 74 */           ((TileUCSign)te).blockOwner = player.getName().getString();
/* 75 */           ((TileUCSign)te).setChanged();
/*    */         } 
/*    */         
/* 78 */         return ActionResultType.SUCCESS;
/*    */       } 
/* 80 */       return ActionResultType.FAIL;
/*    */     } 
/*    */ 
/*    */     
/* 84 */     return ActionResultType.SUCCESS;
/*    */   }
/*    */ }


/* Location:              /home/aspadien/.gradle/caches/forge_gradle/deobf_dependencies/blank/examplemod/1.0.0_mapped_official_1.16.5/examplemod-1.0.0_mapped_official_1.16.5.jar!/aspadien.universalcoins/item/ItemUCSign.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */