/*    */ package aspadien.universalcoins.item;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.util.ITooltipFlag;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.StringTextComponent;
/*    */ import net.minecraft.util.text.TextFormatting;
/*    */ import net.minecraft.util.text.TranslationTextComponent;
/*    */ import net.minecraft.world.World;
/*    */ import aspadien.universalcoins.UniversalCoins;
/*    */ 
/*    */ public class ItemCoin
/*    */   extends Item
/*    */ {
/*    */   private final int coinIndex;
/*    */   
/*    */   public ItemCoin(Item.Properties properties, int coinIndex) {
/* 22 */     super(properties);
/* 23 */     this.coinIndex = coinIndex;
/*    */   }
/*    */ 
/*    */   
/*    */   public void appendHoverText(ItemStack stack, @Nullable World worldIn, List<ITextComponent> tooltip, ITooltipFlag flagIn) {
/* 28 */     super.appendHoverText(stack, worldIn, tooltip, flagIn);
/*    */ 
/*    */     
/* 31 */     int valuePerItem = UniversalCoins.coinValues[this.coinIndex];
/* 32 */     long totalValue = (long) stack.getCount() * valuePerItem;
/*    */     
/* 34 */     DecimalFormat formatter = new DecimalFormat("###,###,###,###,###");
/* 35 */     String formattedValue = formatter.format(totalValue);
/*    */ 
/*    */     
/* 38 */     String translationKey = (totalValue > 1L) ? "general.currency.multiple" : "general.currency.single";
/*    */ 
/*    */ 
/*    */     
/* 42 */     tooltip.add((new StringTextComponent(formattedValue + " "))
/* 43 */         .append(new TranslationTextComponent(translationKey))
/* 44 */         .withStyle(TextFormatting.GOLD));
/*    */   }
/*    */ }
