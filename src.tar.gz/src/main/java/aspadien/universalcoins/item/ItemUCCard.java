/*    */ package aspadien.universalcoins.item;
/*    */ import java.text.DecimalFormat;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nullable;
/*    */ import net.minecraft.client.util.ITooltipFlag;
/*    */ import net.minecraft.entity.player.PlayerEntity;
/*    */ import net.minecraft.item.Item;
/*    */ import net.minecraft.item.ItemStack;
/*    */ import net.minecraft.item.ItemUseContext;
/*    */ import net.minecraft.nbt.CompoundNBT;
/*    */ import net.minecraft.util.ActionResultType;
/*    */ import net.minecraft.util.Util;
/*    */ import net.minecraft.util.text.IFormattableTextComponent;
/*    */ import net.minecraft.util.text.ITextComponent;
/*    */ import net.minecraft.util.text.StringTextComponent;
/*    */ import net.minecraft.util.text.TextFormatting;
/*    */ import net.minecraft.util.text.TranslationTextComponent;
/*    */ import net.minecraft.world.World;
/*    */ import aspadien.universalcoins.util.UniversalAccounts;
/*    */ 
/*    */ public class ItemUCCard extends Item {
/*    */   public ItemUCCard(Item.Properties properties) {
/* 23 */     super(properties.stacksTo(1));
/*    */   }
/*    */ 
/*    */   
/*    */   public void appendHoverText(ItemStack stack, @Nullable World worldIn, List<ITextComponent> tooltip, ITooltipFlag flagIn) {
/* 28 */     if (stack.hasTag()) {
/* 29 */       CompoundNBT tag = stack.getTag();
/*    */       
/* 31 */       tooltip.add((new StringTextComponent(tag.getString("Name"))).withStyle(TextFormatting.GRAY));
/* 32 */       tooltip.add((new StringTextComponent(tag.getString("Account"))).withStyle(TextFormatting.AQUA));
/*    */     } else {
/*    */       
/* 35 */       tooltip.add((new TranslationTextComponent("item.card.warning")).withStyle(TextFormatting.RED));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public ActionResultType useOn(ItemUseContext context) {
/* 41 */     World world = context.getLevel();
/* 42 */     PlayerEntity player = context.getPlayer();
/* 43 */     ItemStack stack = context.getItemInHand();
/*    */     
/* 45 */     if (world.isClientSide || player == null) {
/* 46 */       return ActionResultType.SUCCESS;
/*    */     }
/*    */ 
/*    */     
/* 50 */     if (!stack.hasTag()) {
/* 51 */       createNBT(stack, world, player);
/*    */     }
/*    */ 
/*    */     
/* 55 */     String accountId = stack.getTag().getString("Account");
/* 56 */     long accountCoins = UniversalAccounts.getInstance().getAccountBalance(accountId);
/*    */     
/* 58 */     DecimalFormat formatter = new DecimalFormat("###,###,###,###,###,###,###");
/*    */ 
/*    */ 
/*    */     
/* 62 */     IFormattableTextComponent iFormattableTextComponent = (new TranslationTextComponent("item.card.balance")).append((ITextComponent)(new StringTextComponent(": " + formatter.format(accountCoins))).withStyle(TextFormatting.GOLD));
/*    */     
/* 64 */     player.sendMessage((ITextComponent)iFormattableTextComponent, Util.NIL_UUID);
/*    */     
/* 66 */     return ActionResultType.SUCCESS;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onCraftedBy(ItemStack stack, World world, PlayerEntity player) {
/* 72 */     if (!world.isClientSide) {
/* 73 */       createNBT(stack, world, player);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void createNBT(ItemStack stack, World world, PlayerEntity player) {
/* 80 */     String accountNumber = UniversalAccounts.getInstance().getOrCreatePlayerAccount(player.getUUID().toString());
/*    */     
/* 82 */     CompoundNBT tag = stack.getOrCreateTag();
/* 83 */     tag.putString("Name", player.getName().getString());
/* 84 */     tag.putString("Owner", player.getUUID().toString());
/* 85 */     tag.putString("Account", accountNumber);
/*    */   }
/*    */ }


/* Location:              /home/aspadien/.gradle/caches/forge_gradle/deobf_dependencies/blank/examplemod/1.0.0_mapped_official_1.16.5/examplemod-1.0.0_mapped_official_1.16.5.jar!/aspadien.universalcoins/item/ItemUCCard.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */