/*    */ package aspadien.universalcoins.net;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.entity.player.ServerPlayerEntity;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.network.NetworkEvent;
/*    */ import aspadien.universalcoins.tileentity.TileATM;
/*    */ 
/*    */ public class ATMWithdrawalMessage
/*    */ {
/*    */   private final BlockPos pos;
/*    */   private final int withdrawalAmount;
/*    */   
/*    */   public ATMWithdrawalMessage(BlockPos pos, int amount) {
/* 18 */     this.pos = pos;
/* 19 */     this.withdrawalAmount = amount;
/*    */   }
/*    */   
/*    */   public static void encode(ATMWithdrawalMessage msg, PacketBuffer buf) {
/* 23 */     buf.writeBlockPos(msg.pos);
/* 24 */     buf.writeInt(msg.withdrawalAmount);
/*    */   }
/*    */   
/*    */   public static ATMWithdrawalMessage decode(PacketBuffer buf) {
/* 28 */     return new ATMWithdrawalMessage(buf.readBlockPos(), buf.readInt());
/*    */   }
/*    */   
/*    */   public static void handle(ATMWithdrawalMessage msg, Supplier<NetworkEvent.Context> ctx) {
/* 32 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*    */           ServerPlayerEntity player = ((NetworkEvent.Context)ctx.get()).getSender();
/*    */           if (player == null)
/*    */             return; 
/*    */           World world = player.level;
/*    */           if (world.isLoaded(msg.pos)) {
/*    */             TileEntity te = world.getBlockEntity(msg.pos);
/*    */             if (te instanceof TileATM)
/*    */               ((TileATM)te).startCoinWithdrawal(msg.withdrawalAmount); 
/*    */           } 
/*    */         });
/* 43 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ }


/* Location:              /home/aspadien/.gradle/caches/forge_gradle/deobf_dependencies/blank/examplemod/1.0.0_mapped_official_1.16.5/examplemod-1.0.0_mapped_official_1.16.5.jar!/aspadien.universalcoins/net/ATMWithdrawalMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */