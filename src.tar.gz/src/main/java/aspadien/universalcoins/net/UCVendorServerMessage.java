/*    */ package aspadien.universalcoins.net;
/*    */ 
/*    */ import java.util.function.Supplier;
/*    */ import net.minecraft.block.BlockState;
/*    */ import net.minecraft.entity.player.ServerPlayerEntity;
/*    */ import net.minecraft.network.PacketBuffer;
/*    */ import net.minecraft.tileentity.TileEntity;
/*    */ import net.minecraft.util.math.BlockPos;
/*    */ import net.minecraft.world.World;
/*    */ import net.minecraftforge.fml.network.NetworkEvent;
/*    */ import aspadien.universalcoins.tileentity.TileVendor;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class UCVendorServerMessage
/*    */ {
/*    */   private final BlockPos pos;
/*    */   private final int itemPrice;
/*    */   private final String blockOwner;
/*    */   private final boolean infinite;
/*    */   
/*    */   public UCVendorServerMessage(BlockPos pos, int price, String blockOwner, boolean infinite) {
/* 23 */     this.pos = pos;
/* 24 */     this.itemPrice = price;
/* 25 */     this.blockOwner = blockOwner;
/* 26 */     this.infinite = infinite;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void encode(UCVendorServerMessage msg, PacketBuffer buf) {
/* 31 */     buf.writeBlockPos(msg.pos);
/* 32 */     buf.writeInt(msg.itemPrice);
/* 33 */     buf.writeUtf(msg.blockOwner);
/* 34 */     buf.writeBoolean(msg.infinite);
/*    */   }
/*    */ 
/*    */   
/*    */   public static UCVendorServerMessage decode(PacketBuffer buf) {
/* 39 */     return new UCVendorServerMessage(buf
/* 40 */         .readBlockPos(), buf
/* 41 */         .readInt(), buf
/* 42 */         .readUtf(32767), buf
/* 43 */         .readBoolean());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void handle(UCVendorServerMessage msg, Supplier<NetworkEvent.Context> ctx) {
/* 49 */     ((NetworkEvent.Context)ctx.get()).enqueueWork(() -> {
/*    */           ServerPlayerEntity player = ((NetworkEvent.Context)ctx.get()).getSender();
/*    */           
/*    */           if (player == null) {
/*    */             return;
/*    */           }
/*    */           
/*    */           World world = player.level;
/*    */           
/*    */           if (world.isLoaded(msg.pos)) {
/*    */             TileEntity tileEntity = world.getBlockEntity(msg.pos);
/*    */             
/*    */             if (tileEntity instanceof TileVendor) {
/*    */               TileVendor vendor = (TileVendor)tileEntity;
/*    */               
/*    */               vendor.itemPrice = msg.itemPrice;
/*    */               
/*    */               vendor.blockOwner = msg.blockOwner;
/*    */               
/*    */               vendor.infiniteMode = msg.infinite;
/*    */               
/*    */               vendor.setChanged();
/*    */               
/*    */               vendor.updateTE();
/*    */               BlockState state = world.getBlockState(msg.pos);
/*    */               world.sendBlockUpdated(msg.pos, state, state, 3);
/*    */             } 
/*    */           } 
/*    */         });
/* 78 */     ((NetworkEvent.Context)ctx.get()).setPacketHandled(true);
/*    */   }
/*    */ }


/* Location:              /home/aspadien/.gradle/caches/forge_gradle/deobf_dependencies/blank/examplemod/1.0.0_mapped_official_1.16.5/examplemod-1.0.0_mapped_official_1.16.5.jar!/aspadien.universalcoins/net/UCVendorServerMessage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */